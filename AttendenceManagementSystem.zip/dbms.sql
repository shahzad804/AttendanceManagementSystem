-- Create the database
CREATE DATABASE IF NOT EXISTS student_attendance;
USE student_attendance;

-- Table for user credentials (used in Login and Signup)
CREATE TABLE user_information (
    User_Id INT PRIMARY KEY,
    User_Password VARCHAR(255) NOT NULL,
    Role ENUM('Student', 'Faculty', 'Administrator') NOT NULL
);

-- Table for student profiles (used in Administrator for creating student profiles)
CREATE TABLE student (
    Student_Id INT PRIMARY KEY,
    First_Name VARCHAR(50) NOT NULL,
    Last_Name VARCHAR(50) NOT NULL,
    Street_Address VARCHAR(100),
    City VARCHAR(50),
    Postal_Code VARCHAR(4), -- Based on error message requiring 4 digits
    Mobile_No VARCHAR(11), -- Based on error message requiring 11 digits
    Email VARCHAR(100),
    User_Id INT,
    FOREIGN KEY (User_Id) REFERENCES user_information(User_Id)
);

-- Table for faculty profiles (used in Administrator for creating faculty profiles)
CREATE TABLE faculty_information (
    Faculty_Id INT PRIMARY KEY,
    Faculty_Name VARCHAR(100) NOT NULL,
    Department VARCHAR(50),
    Mobile_No VARCHAR(11),
    Email VARCHAR(100),
    User_Id INT,
    FOREIGN KEY (User_Id) REFERENCES user_information(User_Id)
);

-- Table for course details (used in Administrator for launching courses)
CREATE TABLE course_information (
    Course_Id INT PRIMARY KEY,
    Course_Initial VARCHAR(20) NOT NULL, -- e.g., 'CSE101'
    Course_Name VARCHAR(100) NOT NULL,
    Semester ENUM('Spring', 'Summer', 'Fall') NOT NULL,
    Year VARCHAR(4) NOT NULL, -- e.g., '2023'
    Section VARCHAR(10), -- e.g., 'A', 'B'
    Faculty_Id INT,
    FOREIGN KEY (Faculty_Id) REFERENCES faculty_information(Faculty_Id)
);

-- Table for attendance records (used in Faculty for taking attendance and Student for viewing)
CREATE TABLE attendance (
    Date DATE NOT NULL,
    Student_Id INT NOT NULL,
    Course_Id INT NOT NULL,
    Course_Initial VARCHAR(20) NOT NULL,
    Faculty_Id INT NOT NULL,
    Status ENUM('Present', 'Absent', 'Late') NOT NULL,
    PRIMARY KEY (Date, Student_Id, Course_Id),
    FOREIGN KEY (Student_Id) REFERENCES student(Student_Id),
    FOREIGN KEY (Course_Id) REFERENCES course_information(Course_Id),
    FOREIGN KEY (Faculty_Id) REFERENCES faculty_information(Faculty_Id)
);

-- Table for messages sent by faculty (used in Faculty for sending messages)
CREATE TABLE message (
    Message_Text TEXT NOT NULL,
    Course_Id INT NOT NULL,
    Faculty_Id INT NOT NULL,
    PRIMARY KEY (Course_Id, Faculty_Id),
    FOREIGN KEY (Course_Id) REFERENCES course_information(Course_Id),
    FOREIGN KEY (Faculty_Id) REFERENCES faculty_information(Faculty_Id)
);

-- Table for administrator details (used in Administrator for updating admin info)
CREATE TABLE administrator (
    Administrator_Id INT PRIMARY KEY,
    Administrator_Name VARCHAR(100) NOT NULL,
    User_Id INT,
    FOREIGN KEY (User_Id) REFERENCES user_information(User_Id)
);

-- Table for student-course relationships (used in Administrator for assigning students to courses)
CREATE TABLE student_has_course_information (
    Student_Id INT NOT NULL,
    Course_Id INT NOT NULL,
    Course_Initial VARCHAR(20) NOT NULL,
    Faculty_Id INT NOT NULL,
    PRIMARY KEY (Student_Id, Course_Id),
    FOREIGN KEY (Student_Id) REFERENCES student(Student_Id),
    FOREIGN KEY (Course_Id) REFERENCES course_information(Course_Id),
    FOREIGN KEY (Faculty_Id) REFERENCES faculty_information(Faculty_Id)
);